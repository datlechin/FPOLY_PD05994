ALTER TABLE khachang ADD UNIQUE (soDienThoai, email);
