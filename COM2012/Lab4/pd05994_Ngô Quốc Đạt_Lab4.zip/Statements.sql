CREATE DATABASE `quanlyduan`;
USE `quanlyduan`;

CREATE TABLE `phongban`
(
    `maPB`    int AUTO_INCREMENT NOT NULL,
    `tenPB`   varchar(255)       NOT NULL,
    `diaDiem` varchar(255)       NOT NULL,
    PRIMARY KEY (`maPB`)
);

CREATE TABLE `nhanvien`
(
    `maNV`     int AUTO_INCREMENT NOT NULL,
    `hoTen`    varchar(255)       NOT NULL,
    `ngaySinh` DATE               NOT NULL,
    `luong`    int DEFAULT 0,
    `maPB`     int                NOT NULL,
    CHECK ( `luong` >= 0 ),
    PRIMARY KEY (`maNV`),
    FOREIGN KEY (`maPB`) REFERENCES `phongban` (`maPB`)
);

CREATE TABLE `truongphong`
(
    `maPB` int,
    `maNV` int,
    PRIMARY KEY (`maPB`, `maNV`),
    UNIQUE (`maPB`, `maNV`),
    FOREIGN KEY (`maPB`) REFERENCES `phongban` (`maPB`),
    FOREIGN KEY (`maNV`) REFERENCES `nhanvien` (`maNV`)
);

CREATE TABLE `thannhan`
(
    `maTN`     int AUTO_INCREMENT NOT NULL,
    `hoTen`    varchar(255)       NOT NULL,
    `ngaySinh` date DEFAULT NULL,
    `lienHe`   varchar(50)        NOT NULL,
    `maNV`     int                NOT NULL,
    PRIMARY KEY (`maTN`),
    FOREIGN KEY (`maNV`) REFERENCES `nhanvien` (`maNV`)
);

CREATE TABLE `chusohuu`
(
    `maCSH`       int AUTO_INCREMENT NOT NULL,
    `hoTen`       varchar(255)       NOT NULL,
    `soDienThoai` varchar(50)  DEFAULT NULL,
    `email`       varchar(50)  DEFAULT NULL,
    `diaChi`      varchar(255) DEFAULT NULL,
    PRIMARY KEY (`maCSH`)
);

CREATE TABLE `duan`
(
    `maDA`   int AUTO_INCREMENT NOT NULL,
    `tenDA`  varchar(255)       NOT NULL,
    `diaChi` varchar(255)       NOT NULL,
    `maPB`   int                NOT NULL,
    `maCSH`  int                NOT NULL,
    PRIMARY KEY (`maDA`),
    FOREIGN KEY (`maCSH`) REFERENCES `chusohuu` (`maCSH`),
    FOREIGN KEY (`maPB`) REFERENCES `phongban` (`maPB`)
);

CREATE TABLE `phancong`
(
    `maDA`        int,
    `maNV`        int,
    `ngayBatDau`  date,
    `ngayKetThuc` date,
    CHECK ( `ngayBatDau` < `ngayKetThuc` ),
    PRIMARY KEY (`maDA`, `maNV`),
    FOREIGN KEY (`maDA`) REFERENCES `duan` (`maDA`),
    FOREIGN KEY (`maNV`) REFERENCES `nhanvien` (`maNV`)
);

ALTER TABLE `nhanvien` ADD `gioiTinh` ENUM ('Nam', 'Nữ') NOT NULL DEFAULT 'Nam' AFTER `ngaySinh`;

ALTER TABLE `phongban` DROP COLUMN `diaDiem`;

ALTER TABLE `duan`
    DROP COLUMN `diaChi`,
    DROP FOREIGN KEY `duan_ibfk_1`,
    DROP COLUMN `maCSH`,
    ADD COLUMN `ngayBatDau` date NOT NULL AFTER `tenDA`,
    ADD COLUMN `ngayKetThuc` date NOT NULL AFTER `ngayBatDau`;

ALTER TABLE `phancong`
    ADD COLUMN `soGio` int NOT NULL AFTER `ngayKetThuc`,
    ADD COLUMN `vaiTro` varchar(255) NOT NULL AFTER `soGio`;

INSERT INTO `nhanvien`
VALUES (1, 'Nguyễn An', '1977-01-01', 'Nữ', 15000000, 2),
       (2, 'Lê Bảo', '1982-02-03', 'Nam', 70000000, 1),
       (3, 'Trần Cường', '1988-03-04', 'Nam', 27000000, 5),
       (4, 'Nguyễn Công', '1990-04-05', 'Nam', 30000000, 4),
       (5, 'Nguyễn Đức', '1995-05-06', 'Nam', 50000000, 3),
       (6, 'Nguyễn Hải', '1998-06-07', 'Nam', 80000000, 6),
       (7, 'Nguyễn Hồng', '2001-07-08', 'Nữ', 120000000, 7),
       (8, 'Nguyễn Khắc', '2004-08-09', 'Nam', 20000000, 8),
       (9, 'Nguyễn Minh', '2007-09-10', 'Nam', 30000000, 2),
       (10, 'Nguyễn Ngọc', '2010-10-11', 'Nữ', 50000000, 6),
       (11, 'Nguyễn Phương', '2013-11-12', 'Nam', 70000000, 2),
       (12, 'Nguyễn Quang', '2016-12-13', 'Nam', 100000000, 5);

INSERT INTO `phongban`
VALUES (1, 'Phòng ban 1'),
       (2, 'Phòng ban 2'),
       (3, 'Quản lý chất lượng'),
       (4, 'Thiết kế'),
       (5, 'Kế toán'),
       (6, 'Nguyên cứu công nghệ'),
       (7, 'Kinh doanh'),
       (8, 'Truyền thông');

INSERT INTO `truongphong`
VALUES (1, 2),
       (2, 3),
       (3, 4),
       (7, 5),
       (4, 8),
       (5, 9),
       (6, 12);

INSERT INTO `duan`
VALUES (1, 'Library Sytem', '2017-01-01', '2017-03-08', 1),
       (2, 'Employee System', '2017-03-03', '2017-08-14', 3),
       (3, 'Travel Website', '2017-07-09', '2017-08-26', 2),
       (4, 'Lee Fashion Website', '2017-02-09', '2017-10-26', 1);

INSERT INTO `phancong`
VALUES (1, 1, '2017-01-01', '2017-03-08', 300, 'Dev'),
       (1, 7, '2017-01-05', '2017-03-08', 50, 'Designer'),
       (1, 8, '2017-05-01', '2017-08-23', 60, 'QA');
