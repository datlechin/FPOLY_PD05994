package Lab8;

public class Main {
    public static void main(String[] args) {
        System.out.println(FPoly.min(1, 2, 3, 4, 5));
        System.out.println(FPoly.max(1, 2, 3, 4, 5));
        System.out.println(FPoly.sum(1, 2, 3, 4, 5));
        System.out.println(FPoly.toUpperFirstChar("ngô quốc đạt"));
    }
}
